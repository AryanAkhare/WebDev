import React, { useState } from "react";
import "./App.css"; 

function App() {
  const [input, setInput] = useState("");
  
  const handleClick = (value) => {
    setInput((prev) => prev + value);
  };

  const calculate = () => {
    try {
      setInput(eval(input).toString());
    } catch {
      setInput("Error");
    }
  };

  const clearInput = () => {
    setInput("");
  };

  return (
    <div className="calculator">
      <input type="text" value={input} readOnly />
      <div className="buttons">
        {["7", "8", "9", "/"].map((btn) => (
          <button key={btn} onClick={() => handleClick(btn)}>{btn}</button>
        ))}
        {["4", "5", "6", "*"].map((btn) => (
          <button key={btn} onClick={() => handleClick(btn)}>{btn}</button>
        ))}
        {["1", "2", "3", "-"].map((btn) => (
          <button key={btn} onClick={() => handleClick(btn)}>{btn}</button>
        ))}
        {["0", ".", "+", "="].map((btn) => (
          <button key={btn} onClick={btn === "=" ? calculate : () => handleClick(btn)}>{btn}</button>
        ))}
        <button className="clear" onClick={clearInput}>C</button>
      </div>
    </div>
  );
}

export default App;
